# Relay — AI Context Bridge

**Your memory. Every AI.**

Relay is a browser extension that saves your context from any AI session and injects it into any other — across Claude, ChatGPT, Gemini, Grok, and every model that comes next.

---

## The Problem

AI forgets you the moment the tab closes. And even when memory exists, it's locked to one platform. Claude remembers you on Claude. ChatGPT on ChatGPT. None of it travels.

You spend the first five minutes of every session re-explaining your project, your preferences, your decisions. That's your time, not the AI's.

## The Fix

```
Save on Claude  →  Inject into ChatGPT  →  Continue where you left off
```

Relay sits in your browser across every AI interface. One shortcut to save. One shortcut to inject. Your context travels with you, not with the platform you're paying.

---

## Install (Developer Mode)

1. Download or clone this repo
2. Open Chrome → `chrome://extensions`
3. Enable **Developer Mode** (top right)
4. Click **Load unpacked** → select the `relay-extension` folder
5. Relay button appears automatically on Claude, ChatGPT, Gemini, Grok

Chrome Web Store submission in progress.

---

## Usage

| Action | Shortcut | Description |
|---|---|---|
| Save context | `⌘⇧R` / `Ctrl⇧R` | Captures current session state |
| Inject context | `⌘⇧I` / `Ctrl⇧I` | Opens saved context list |
| Toggle panel | Click Relay button | Shows/hides the Relay panel |

Or use the Relay button in the bottom-right corner of any supported AI interface.

---

## Supported Platforms

- ✅ Claude (claude.ai)
- ✅ ChatGPT (chat.openai.com, chatgpt.com)
- ✅ Gemini (gemini.google.com)
- ✅ Grok (grok.com)
- 🔜 Perplexity
- 🔜 Mistral

---

## Your Data

- **Local by default.** Contexts stored in `chrome.storage.local`. Nothing leaves your browser.
- **GitHub sync (optional).** Add your own repo + token in settings. Your repo, your data.
- **No accounts.** No tracking. No servers. The core feature is offline.

---

## The ILYJ Protocol

Relay stores context in the **ILYJ format** — an open, model-agnostic JSON spec for AI session state.

```json
{
  "protocol": "ILYJ_SYNC_v1",
  "version": 1,
  "savedAt": "2026-03-28T11:49:00Z",
  "sourcePlatform": "Claude",
  "context": {
    "summary": "Building a browser extension for AI context portability...",
    "keyDecisions": ["Local-first storage", "Open format", "Free core tier"],
    "openQuestions": ["Backend sync architecture"]
  }
}
```

ILYJ is a public domain standard — CC0, no restrictions. Build on it, implement it, fork it.

→ [ILYJ Specification](../ilyj-spec/ILYJ-SPEC.md)

---

## Roadmap

**V0.1 — Now**
- [x] Chrome extension (Manifest V3)
- [x] Save / inject context
- [x] Keyboard shortcuts
- [x] Local storage

**V0.2 — Next**
- [ ] GitHub sync
- [ ] Named context slots
- [ ] Delete / rename contexts
- [ ] Firefox support

**V1.0**
- [ ] Relay Sync (encrypted cloud, optional)
- [ ] Mobile companion app
- [ ] Context search + tags
- [ ] Team shared contexts

---

## Contributing

PRs welcome. The biggest maintenance surface is DOM selectors — AI platforms update their UIs constantly. If a platform breaks, open an issue with the new selector.

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## License

MIT — do whatever you want with the code.  
ILYJ spec is CC0 — public domain.

---

*Started as an iOS Shortcuts + GitHub API hack. The idea was right. The browser is the right layer.*
