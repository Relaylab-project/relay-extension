# Relay — Technical Spec & Product Roadmap
## Version 0.1 — Internal Document

---

## What Is Relay

Relay is a browser extension that creates a portable, user-owned memory layer for AI models. It saves conversation context from any AI interface and injects it into any other — across platforms, sessions, and devices.

**Core insight:** AI memory is siloed by platform and locked to a single vendor. Relay is a neutral, open-format bridge that the user owns entirely.

---

## The ILYJ Protocol

ILYJ (the context format Relay uses) is a structured JSON schema for AI session state. Every saved context is a valid ILYJ document.

```json
{
  "protocol": "ILYJ_SYNC_v1",
  "name": "Claude — March 28 2026, 11:49 AM",
  "savedAt": "2026-03-28T11:49:00Z",
  "sourcePlatform": "Claude",
  "sourceUrl": "https://claude.ai/chat/abc123",
  "conversationExcerpt": "...",
  "userNotes": "",
  "tags": [],
  "version": 1
}
```

**Why an open format matters:**
- Any AI can read a raw ILYJ block — it's just structured text
- Documents are human-readable
- Can be versioned in Git
- Not tied to Relay as a product

---

## Architecture

### V0.1 — Extension MVP (Local Storage)

```
Browser Extension
├── content.js       — Detects AI interface, injects Relay UI button
├── popup.html/js    — Extension popup with context list
├── background.js    — Handles keyboard shortcuts
└── manifest.json    — Chrome Manifest V3

Storage
└── chrome.storage.local
    └── relay_contexts[]   — Array of ILYJ documents (last 50)
```

**Supported platforms at launch:**
- Claude (claude.ai)
- ChatGPT (chat.openai.com, chatgpt.com)
- Gemini (gemini.google.com)
- Grok (grok.com)

### V0.2 — GitHub Sync

User provides a personal GitHub repo + token. Relay pushes/pulls ILYJ files to that repo. This is the origin of the project — the iOS Shortcut prototype proved the concept.

```
Extension ──push──▶ GitHub Repo (user-owned)
                         │
iOS Shortcut ────pull────┘
Mobile app (future)
```

### V1.0 — Relay Sync (Optional Cloud)

Optional hosted sync layer for users who don't want to manage GitHub. Encrypted at rest, user holds the key. Revenue model: subscription.

---

## Extension — Key Technical Details

### Platform Detection
```javascript
const PLATFORMS = {
  'claude.ai': { inputSelector: '.ProseMirror, div[contenteditable]' },
  'chat.openai.com': { inputSelector: '#prompt-textarea' },
  'gemini.google.com': { inputSelector: '.ql-editor' },
  // ...
}
```

### Context Extraction
Relay reads the last N DOM elements matching message selectors. This is fragile — platforms change their DOM. V0.2 will explore a clipboard-based capture fallback.

### Injection Strategy
1. Try direct DOM injection (contenteditable / textarea)
2. Fall back to clipboard + notification

### SPA Navigation
All target platforms are SPAs. Relay uses a MutationObserver to detect URL changes and re-inject the Relay button after navigation.

---

## Roadmap

### Now — V0.1 (MVP)
- [x] Manifest V3 extension scaffold
- [x] Platform detection (Claude, ChatGPT, Gemini, Grok)
- [x] Save context (local storage)
- [x] Inject context into input
- [x] Keyboard shortcuts (⌘⇧R / ⌘⇧I)
- [x] Popup UI
- [ ] Icons and Chrome Web Store assets
- [ ] Submit to Chrome Web Store

### Next — V0.2 (GitHub Sync)
- [ ] GitHub API integration in popup settings
- [ ] Push context to user's repo on save
- [ ] Pull latest context from repo
- [ ] Named context slots (not just timestamps)
- [ ] Delete / rename contexts

### Later — V0.3 (Polish)
- [ ] Firefox support (WebExtension API compatible)
- [ ] Context search
- [ ] Tag system for contexts
- [ ] Auto-save option on session start
- [ ] Context diff viewer (what changed between sessions)

### V1.0 (Product)
- [ ] Relay Sync (optional hosted backend)
- [ ] Mobile companion app (finally the right implementation of the iOS concept)
- [ ] Context templates (project types, personas)
- [ ] Team contexts (shared context for teams using AI together)
- [ ] API for developers

---

## Business Model

**Free tier:** Local storage, up to 50 contexts, GitHub sync. Always free.

**Pro ($5/month):** Relay Sync (encrypted cloud), unlimited contexts, cross-device, mobile app, priority support.

**Team ($12/seat/month):** Shared team contexts, admin controls, SSO.

---

## Competitive Landscape

| Product | Approach | Limitation |
|---|---|---|
| Claude Memory | Built-in memory | Claude only |
| ChatGPT Memory | Built-in memory | ChatGPT only |
| Mem.ai | AI note-taking | Not AI-to-AI |
| Notion AI | Document AI | Separate workflow |
| **Relay** | Neutral portable layer | None — by design |

**The gap:** No one owns the space between AI models. Relay does.

---

## Install Instructions (Developer Mode)

Until the Chrome Web Store submission:

1. Download the `relay-extension` folder
2. Open Chrome → `chrome://extensions`
3. Enable **Developer Mode** (top right toggle)
4. Click **Load unpacked**
5. Select the `relay-extension` folder
6. Relay button appears on Claude, ChatGPT, Gemini automatically

---

## Known Issues (V0.1)

- DOM selectors may break when AI platforms update their UI
- Gemini injection is unreliable due to custom editor implementation
- No sync between devices in V0.1
- Icons not yet included (extension loads without them, shows text only)

---

*Built from an iOS Shortcuts proof of concept. The idea was right. The implementation just needed to move to the browser.*
