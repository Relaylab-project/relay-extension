// Relay Popup Script

const AI_HOSTS = ['claude.ai', 'chat.openai.com', 'chatgpt.com', 'gemini.google.com', 'grok.com'];

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = new URL(tab.url).hostname;
  const isAI = AI_HOSTS.some(h => host.includes(h));

  const status = document.getElementById('statusLabel');
  status.textContent = isAI ? `● ${host.split('.')[0]}` : '● not an AI tab';
  status.className = `status ${isAI ? 'active' : ''}`;

  loadContexts();
  loadSettings();
}

async function loadContexts() {
  const result = await chrome.storage.local.get('relay_contexts');
  const contexts = result.relay_contexts || [];
  const list = document.getElementById('contextList');

  if (contexts.length === 0) {
    list.innerHTML = '<div class="empty">No contexts saved yet.<br>Visit any AI and hit Save.</div>';
    return;
  }

  list.innerHTML = contexts.map(ctx => `
    <div class="context-item" data-id="${ctx.id}">
      <div class="context-name">${ctx.name}</div>
      <div class="context-meta">${ctx.sourcePlatform} · ${new Date(ctx.savedAt).toLocaleDateString()}</div>
    </div>
  `).join('');

  list.querySelectorAll('.context-item').forEach(item => {
    item.addEventListener('click', () => injectContext(item.dataset.id, contexts));
  });
}

async function injectContext(id, contexts) {
  const ctx = contexts.find(c => String(c.id) === String(id));
  if (!ctx) return;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (ctxData) => {
      const text = `[RELAY CONTEXT — ILYJ_SYNC_v1]
Source: ${ctxData.sourcePlatform} · ${new Date(ctxData.savedAt).toLocaleString()}

${ctxData.conversationExcerpt}

[Please acknowledge this context and continue.]`;

      const selectors = [
        '#prompt-textarea',
        '.ProseMirror',
        'div[contenteditable="true"]',
        '.ql-editor',
        'textarea'
      ];

      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) {
          el.focus();
          if (el.tagName === 'TEXTAREA') {
            el.value = text;
            el.dispatchEvent(new Event('input', { bubbles: true }));
          } else {
            document.execCommand('insertText', false, text);
          }
          return 'injected';
        }
      }
      return 'not_found';
    },
    args: [ctx]
  });

  window.close();
}

// Save from popup
document.getElementById('btnSave').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      document.getElementById('relay-save')?.click();
    }
  });
  window.close();
});

// Settings toggle
document.getElementById('toggleSettings').addEventListener('click', e => {
  e.preventDefault();
  const s = document.getElementById('settingsSection');
  s.style.display = s.style.display === 'none' ? 'block' : 'none';
});

// Save settings
document.getElementById('saveSettings').addEventListener('click', async () => {
  const repo = document.getElementById('githubRepo').value.trim();
  const token = document.getElementById('githubToken').value.trim();
  await chrome.storage.local.set({ relay_github: { repo, token } });
  document.getElementById('saveSettings').textContent = '✓ Saved';
  setTimeout(() => { document.getElementById('saveSettings').textContent = 'Save Settings'; }, 2000);
});

async function loadSettings() {
  const result = await chrome.storage.local.get('relay_github');
  if (result.relay_github) {
    document.getElementById('githubRepo').value = result.relay_github.repo || '';
    document.getElementById('githubToken').value = result.relay_github.token || '';
  }
}

init();
