// Relay Content Script
// Detects which AI platform we're on and injects the Relay UI

const PLATFORMS = {
  'claude.ai': {
    name: 'Claude',
    inputSelector: '[data-placeholder], .ProseMirror, div[contenteditable="true"]',
    color: '#e8843a'
  },
  'chat.openai.com': {
    name: 'ChatGPT',
    inputSelector: '#prompt-textarea, [data-id="root"]',
    color: '#10a37f'
  },
  'chatgpt.com': {
    name: 'ChatGPT',
    inputSelector: '#prompt-textarea',
    color: '#10a37f'
  },
  'gemini.google.com': {
    name: 'Gemini',
    inputSelector: '.ql-editor, [contenteditable="true"]',
    color: '#4285f4'
  },
  'grok.com': {
    name: 'Grok',
    inputSelector: 'textarea, [contenteditable="true"]',
    color: '#1da1f2'
  }
};

function detectPlatform() {
  const host = window.location.hostname;
  return Object.keys(PLATFORMS).find(k => host.includes(k));
}

function injectRelayButton() {
  if (document.getElementById('relay-btn')) return;

  const platformKey = detectPlatform();
  if (!platformKey) return;

  const platform = PLATFORMS[platformKey];

  const btn = document.createElement('div');
  btn.id = 'relay-btn';
  btn.innerHTML = `
    <div id="relay-widget">
      <button id="relay-toggle" title="Relay Context Bridge">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <circle cx="3" cy="8" r="2" fill="currentColor"/>
          <circle cx="13" cy="8" r="2" fill="currentColor"/>
          <path d="M5 8h6" stroke="currentColor" stroke-width="1.5"/>
          <circle cx="8" cy="5" r="1.5" fill="currentColor" opacity="0.6"/>
        </svg>
        relay
      </button>
      <div id="relay-panel" style="display:none">
        <div class="relay-header">
          <span class="relay-platform">${platform.name}</span>
          <span class="relay-title">Context Bridge</span>
        </div>
        <div class="relay-actions">
          <button class="relay-action-btn" id="relay-save">
            ↑ Save Context
          </button>
          <button class="relay-action-btn secondary" id="relay-inject">
            ↓ Inject Context
          </button>
        </div>
        <div id="relay-contexts" class="relay-contexts">
          <div class="relay-empty">No saved contexts yet</div>
        </div>
        <div class="relay-footer">
          <a href="#" id="relay-settings">⚙ Settings</a>
          <span>relay v0.1</span>
        </div>
      </div>
    </div>
  `;

  const style = document.createElement('style');
  style.textContent = `
    #relay-widget {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 999999;
      font-family: 'DM Mono', 'Fira Code', monospace;
    }

    #relay-toggle {
      background: #080808;
      color: #e8ff47;
      border: 1px solid #e8ff47;
      padding: 10px 16px;
      font-family: inherit;
      font-size: 12px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s;
      box-shadow: 0 4px 20px rgba(0,0,0,0.4);
    }

    #relay-toggle:hover {
      background: #e8ff47;
      color: #080808;
    }

    #relay-panel {
      position: absolute;
      bottom: 52px;
      right: 0;
      width: 280px;
      background: #111;
      border: 1px solid #1f1f1f;
      box-shadow: 0 8px 40px rgba(0,0,0,0.6);
    }

    .relay-header {
      padding: 14px 16px;
      border-bottom: 1px solid #1f1f1f;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .relay-platform {
      color: ${platform.color};
      font-size: 11px;
      font-weight: 500;
    }

    .relay-title {
      color: #555;
      font-size: 11px;
    }

    .relay-actions {
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      border-bottom: 1px solid #1f1f1f;
    }

    .relay-action-btn {
      background: #e8ff47;
      color: #080808;
      border: none;
      padding: 10px 14px;
      font-family: inherit;
      font-size: 12px;
      cursor: pointer;
      text-align: left;
      transition: opacity 0.2s;
    }

    .relay-action-btn:hover { opacity: 0.85; }

    .relay-action-btn.secondary {
      background: #1a1a1a;
      color: #e8ff47;
      border: 1px solid #2a2a2a;
    }

    .relay-action-btn.secondary:hover {
      border-color: #e8ff47;
    }

    .relay-contexts {
      max-height: 200px;
      overflow-y: auto;
      padding: 8px;
    }

    .relay-empty {
      color: #444;
      font-size: 11px;
      text-align: center;
      padding: 16px;
    }

    .relay-context-item {
      padding: 10px 12px;
      border: 1px solid #1f1f1f;
      margin-bottom: 6px;
      cursor: pointer;
      transition: border-color 0.2s;
    }

    .relay-context-item:hover { border-color: #e8ff47; }

    .relay-context-name {
      color: #f0f0f0;
      font-size: 12px;
      margin-bottom: 4px;
    }

    .relay-context-meta {
      color: #444;
      font-size: 10px;
    }

    .relay-footer {
      padding: 10px 16px;
      border-top: 1px solid #1f1f1f;
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: #444;
    }

    .relay-footer a { color: #555; text-decoration: none; }
    .relay-footer a:hover { color: #e8ff47; }
  `;

  document.head.appendChild(style);
  document.body.appendChild(btn);

  // Toggle panel
  document.getElementById('relay-toggle').addEventListener('click', () => {
    const panel = document.getElementById('relay-panel');
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    loadContextList();
  });

  // Save context
  document.getElementById('relay-save').addEventListener('click', saveContext);

  // Keyboard shortcuts
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'R') {
      e.preventDefault();
      saveContext();
    }
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'I') {
      e.preventDefault();
      const panel = document.getElementById('relay-panel');
      panel.style.display = 'block';
      loadContextList();
    }
  });
}

function extractPageContext() {
  const platformKey = detectPlatform();
  const platform = PLATFORMS[platformKey];

  // Try to extract conversation text
  let conversationText = '';

  const selectors = [
    '.font-claude-message',        // Claude
    '[data-message-author-role]',  // ChatGPT
    '.model-response-text',        // Gemini
    '[class*="message"]',          // Generic fallback
  ];

  for (const sel of selectors) {
    const msgs = document.querySelectorAll(sel);
    if (msgs.length > 0) {
      conversationText = Array.from(msgs)
        .slice(-10) // Last 10 messages
        .map(m => m.innerText?.trim())
        .filter(Boolean)
        .join('\n\n');
      break;
    }
  }

  return {
    platform: platform?.name || 'Unknown',
    url: window.location.href,
    title: document.title,
    timestamp: new Date().toISOString(),
    conversationExcerpt: conversationText.slice(0, 2000),
  };
}

async function saveContext() {
  const btn = document.getElementById('relay-save');
  btn.textContent = '↑ Saving...';

  try {
    const ctx = extractPageContext();
    const name = `${ctx.platform} — ${new Date().toLocaleString()}`;

    // Build ILYJ format
    const ilyjContext = {
      protocol: 'ILYJ_SYNC_v1',
      name,
      savedAt: ctx.timestamp,
      sourcePlatform: ctx.platform,
      sourceUrl: ctx.url,
      conversationExcerpt: ctx.conversationExcerpt,
      userNotes: '',
    };

    // Get existing contexts
    const result = await chrome.storage.local.get('relay_contexts');
    const contexts = result.relay_contexts || [];
    contexts.unshift({ id: Date.now(), ...ilyjContext });

    // Keep last 50
    if (contexts.length > 50) contexts.pop();

    await chrome.storage.local.set({ relay_contexts: contexts });

    btn.textContent = '✓ Saved!';
    btn.style.background = '#1a1a1a';
    btn.style.color = '#e8ff47';
    btn.style.border = '1px solid #e8ff47';

    setTimeout(() => {
      btn.textContent = '↑ Save Context';
      btn.style.background = '';
      btn.style.color = '';
      btn.style.border = '';
    }, 2000);

    loadContextList();

  } catch (err) {
    btn.textContent = '✗ Error saving';
    console.error('Relay save error:', err);
    setTimeout(() => { btn.textContent = '↑ Save Context'; }, 2000);
  }
}

async function loadContextList() {
  const container = document.getElementById('relay-contexts');
  if (!container) return;

  const result = await chrome.storage.local.get('relay_contexts');
  const contexts = result.relay_contexts || [];

  if (contexts.length === 0) {
    container.innerHTML = '<div class="relay-empty">No saved contexts yet.<br>Press ⌘⇧R to save.</div>';
    return;
  }

  container.innerHTML = contexts.map(ctx => `
    <div class="relay-context-item" data-id="${ctx.id}">
      <div class="relay-context-name">${ctx.name}</div>
      <div class="relay-context-meta">${ctx.sourcePlatform} · ${new Date(ctx.savedAt).toLocaleDateString()}</div>
    </div>
  `).join('');

  container.querySelectorAll('.relay-context-item').forEach(item => {
    item.addEventListener('click', () => injectContext(item.dataset.id, contexts));
  });
}

async function injectContext(id, contexts) {
  const ctx = contexts.find(c => String(c.id) === String(id));
  if (!ctx) return;

  const injectionText = `[RELAY CONTEXT BRIDGE — ILYJ_SYNC_v1]
Source: ${ctx.sourcePlatform} session saved ${new Date(ctx.savedAt).toLocaleString()}

Previous conversation context:
${ctx.conversationExcerpt}

[END RELAY CONTEXT — Please acknowledge this context and continue from here.]`;

  // Try to find the input and inject
  const platformKey = detectPlatform();
  const selectors = PLATFORMS[platformKey]?.inputSelector?.split(', ') || ['textarea'];

  let injected = false;
  for (const sel of selectors) {
    const input = document.querySelector(sel);
    if (input) {
      if (input.tagName === 'TEXTAREA') {
        input.value = injectionText;
        input.dispatchEvent(new Event('input', { bubbles: true }));
      } else if (input.contentEditable === 'true') {
        input.focus();
        document.execCommand('insertText', false, injectionText);
      }
      injected = true;
      break;
    }
  }

  if (!injected) {
    // Fallback: copy to clipboard
    await navigator.clipboard.writeText(injectionText);
    showNotification('Context copied to clipboard — paste it into the chat');
  } else {
    showNotification('Context injected ✓');
  }

  document.getElementById('relay-panel').style.display = 'none';
}

function showNotification(msg) {
  const notif = document.createElement('div');
  notif.style.cssText = `
    position: fixed; bottom: 90px; right: 24px;
    background: #e8ff47; color: #080808;
    padding: 10px 16px; font-family: monospace; font-size: 12px;
    z-index: 9999999; animation: fadeIn 0.3s ease;
  `;
  notif.textContent = msg;
  document.body.appendChild(notif);
  setTimeout(() => notif.remove(), 3000);
}

// Init
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectRelayButton);
} else {
  injectRelayButton();
}

// Re-inject on SPA navigation
let lastUrl = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    setTimeout(injectRelayButton, 1500);
  }
}).observe(document, { subtree: true, childList: true });
