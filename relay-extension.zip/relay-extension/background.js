// Relay Background Service Worker

chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  if (command === 'save-context') {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => document.getElementById('relay-save')?.click()
    });
  }

  if (command === 'inject-context') {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const panel = document.getElementById('relay-panel');
        if (panel) panel.style.display = 'block';
      }
    });
  }
});
